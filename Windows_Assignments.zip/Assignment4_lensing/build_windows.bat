@echo off
REM Build the CUDA lensing program on Windows WITHOUT CFITSIO (writes lens_cuda.pgm).
REM Run from an "x64 Native Tools Command Prompt for VS" (nvcc needs cl.exe).
REM Requires: NVIDIA driver + CUDA Toolkit + Visual Studio Build Tools (C++).
REM Set ARCH to your GPU: sm_61 (GTX10), sm_75 (RTX20/GTX16), sm_86 (RTX30), sm_89 (RTX40)
if "%ARCH%"=="" set ARCH=sm_75
nvcc -O3 -w -arch=%ARCH% -DNO_FITS -o lens_cuda.exe lens_cuda.cu lenses.cpp
if errorlevel 1 exit /b 1
lens_cuda.exe 3 0.005
echo.
echo Open lens_cuda.pgm in IrfanView/GIMP, or:  python -c "from PIL import Image; Image.open('lens_cuda.pgm').save('lens.png')"
