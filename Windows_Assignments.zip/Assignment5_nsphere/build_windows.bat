@echo off
REM Run from "x64 Native Tools Command Prompt for VS" (CUDA Toolkit + VS C++ Build Tools installed)
if "%ARCH%"=="" set ARCH=sm_75
nvcc -O3 -w -arch=%ARCH% -o nsphere.exe nsphere.cu
if errorlevel 1 exit /b 1
nsphere.exe 2 2.05
nsphere.exe 3 1.5
nsphere.exe 1 25.5
nsphere.exe 6 8.0
